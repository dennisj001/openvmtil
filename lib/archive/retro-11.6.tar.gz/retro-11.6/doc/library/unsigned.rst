=========
unsigned'
=========

--------
Overview
--------
This vocabulary will provide support for creation and use of unsigned values.



