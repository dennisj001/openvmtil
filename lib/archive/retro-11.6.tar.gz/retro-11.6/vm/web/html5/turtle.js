portHandlers[30] = function()
{
  if (ports[30] == -1)
    p.go(data.pop()).stroke();

  if (ports[30] == -2)
    p.back(data.pop()).stroke();

  if (ports[30] == -3)
    p.pw(data.pop());

  if (ports[30] == -4)
    p.pc(data.pop());

  if (ports[30] == -5)
    p.pu().stoke();

  if (ports[30] == -6)
    p.pd().stroke();

  if (ports[30] == -7)
    p.stroke().jump(data.pop(), data.pop()).stroke();

  if (ports[30] == -8)
    p.turn(data.pop()).stroke();

  ports[30] = 0;
}
