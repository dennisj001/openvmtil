//
//  Ngaro.m
//  ngaro
//
//  Created by Charles Childers on 3/9/14.
//  Copyright (c) 2014 Charles Childers. All rights reserved.
//
// Copyright (c) 2008 - 2013, Charles Childers
// Copyright (c) 2009 - 2010, Luke Parrish
// Copyright (c) 2010,        Marc Simpson
// Copyright (c) 2010,        Jay Skeer
// Copyright (c) 2011,        Kenneth Keating
//

#import "ngaro.h"

@implementation Ngaro

- (Ngaro *)init
{
    self = [super init];
    isp = 0;
    sp = 0;
    rsp = 0;
    return self;
}

/* Helper Functions ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
- (void)getString: (int)starting
{
    CELL i = 0;
    while(image[starting] && i < MAX_REQUEST_LENGTH)
        request[i++] = (char)image[starting++];
    request[i] = 0;
}

/* Console I/O Support ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
- (void)writeConsole: (CELL)c
{
    (c > 0) ? putchar((char)c) : printf("\033[2J\033[1;1H");
    /* Erase the previous character if c = backspace */
    if (c == 8) {
        putchar(32);
        putchar(8);
    }
}

- (CELL)readConsole
{
    CELL c;
    if ((c = getc(input[isp])) == EOF && input[isp] != stdin) {
        fclose(input[isp--]);
        c = 0;
    }
    if (c == EOF && input[isp] == stdin)
        exit(0);
    return c;
}

- (void)includeFile: (char *)s
{
    FILE *file;
    if ((file = fopen(s, "r")))
        input[++isp] = file;
}

- (void)prepareInput
{
    isp = 0;
    input[isp] = stdin;
}

- (void)prepareOutput
{
    tcgetattr(0, &old_termios);
    new_termios = old_termios;
    new_termios.c_iflag &= ~(BRKINT+ISTRIP+IXON+IXOFF);
    new_termios.c_iflag |= (IGNBRK+IGNPAR);
    new_termios.c_lflag &= ~(ICANON+ISIG+IEXTEN+ECHO);
    new_termios.c_cc[VMIN] = 1;
    new_termios.c_cc[VTIME] = 0;
    tcsetattr(0, TCSANOW, &new_termios);
}

- (void)restoreIO
{
    tcsetattr(0, TCSANOW, &old_termios);
}

/* File I/O Support ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
- (CELL)getFileHandle
{
    CELL i;
    for(i = 1; i < MAX_OPEN_FILES; i++)
        if (files[i] == 0)
            return i;
    return 0;
}

- (void)addInputSource
{
    CELL name = TOS; DROP;
    [self getString: name];
    [self includeFile: request];
}

- (CELL)openFile
{
    CELL slot, mode, name;
    slot = [self getFileHandle];
    mode = TOS; DROP;
    name = TOS; DROP;
    [self getString: name];
    if (slot > 0)
    {
        if (mode == 0)  files[slot] = fopen(request, "r");
        if (mode == 1)  files[slot] = fopen(request, "w");
        if (mode == 2)  files[slot] = fopen(request, "a");
        if (mode == 3)  files[slot] = fopen(request, "r+");
    }
    if (files[slot] == NULL)
    {
        files[slot] = 0;
        slot = 0;
    }
    return slot;
}

- (CELL)readFile
{
    CELL c = fgetc(files[TOS]); DROP;
    return (c == EOF) ? 0 : c;
}

- (CELL)writeFile
{
    CELL slot, c, r;
    slot = TOS; DROP;
    c = TOS; DROP;
    r = fputc(c, files[slot]);
    return (r == EOF) ? 0 : 1;
}

- (CELL)closeFile
{
    fclose(files[TOS]);
    files[TOS] = 0;
    DROP;
    return 0;
}

- (CELL)getFilePosition
{
    CELL slot = TOS; DROP;
    return (CELL) ftell(files[slot]);
}

- (CELL)setFilePosition
{
    CELL slot, pos, r;
    slot = TOS; DROP;
    pos  = TOS; DROP;
    r = fseek(files[slot], pos, SEEK_SET);
    return r;
}

- (CELL)getFileSize
{
    CELL slot, current, r, size;
    slot = TOS; DROP;
    current = (int32_t)ftell(files[slot]);
    r = fseek(files[slot], 0, SEEK_END);
    size = (int32_t)ftell(files[slot]);
    fseek(files[slot], current, SEEK_SET);
    return (r == 0) ? size : 0;
}

- (CELL)deleteFile
{
    CELL name = TOS; DROP;
    [self getString: name];
    return (unlink(request) == 0) ? -1 : 0;
}

- (CELL)loadImage: (char *)imageName
{
    FILE *fp;
    CELL x = 0;
    
    if ((fp = fopen(imageName, "rb")) != NULL) {
        x = fread(&image, sizeof(CELL), IMAGE_SIZE, fp);
        fclose(fp);
    }
    else {
        printf("Unable to find the retroImage!\n");
        exit(1);
    }
    filecells = x;
    return x;
}

- (CELL)saveImage:(char *)imageName
{
    FILE *fp;
    CELL x = 0;
    
    if ((fp = fopen(imageName, "wb")) == NULL)
    {
        printf("Unable to save the retroImage!\n");
        [self restoreIO];
        exit(2);
    }
    
    if (shrink == 0)
        x = fwrite(&image, sizeof(CELL), IMAGE_SIZE, fp);
    else
        x = fwrite(&image, sizeof(CELL), image[3], fp);
    fclose(fp);
    
    return x;
}

/* Environment Query ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
- (void)queryEnvironment
{
    CELL req, dest;
    char *r;
    req = TOS;  DROP;
    dest = TOS; DROP;
    
    [self getString: req];
    r = getenv(request);
    
    if (r != 0)
        while (*r != '\0')
        {
            image[dest] = *r;
            dest++;
            image[dest] = 0;
            r++;
        }
    else
        image[dest] = 0;
}

/* Device I/O Handler ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
- (void)deviceHandler
{
    struct winsize w;
    if (ports[0] != 1) {
        /* Input */
        if (ports[0] == 0 && ports[1] == 1) {
            ports[1] = [self readConsole];
            ports[0] = 1;
        }
        
        /* Output (character generator) */
        if (ports[2] == 1) {
            [self writeConsole: TOS]; DROP
            ports[2] = 0;
            ports[0] = 1;
        }
        
        /* File IO and Image Saving */
        if (ports[4] != 0) {
            ports[0] = 1;
            switch (ports[4]) {
                case  1: [self saveImage: filename];
                    ports[4] = 0;
                    break;
                case  2: [self addInputSource];
                    ports[4] = 0;
                    break;
                case -1: ports[4] = [self openFile];
                    break;
                case -2: ports[4] = [self readFile];
                    break;
                case -3: ports[4] = [self writeFile];
                    break;
                case -4: ports[4] = [self closeFile];
                    break;
                case -5: ports[4] = [self getFilePosition];
                    break;
                case -6: ports[4] = [self setFilePosition];
                    break;
                case -7: ports[4] = [self getFileSize];
                    break;
                case -8: ports[4] = [self deleteFile];
                    break;
                default: ports[4] = 0;
            }
        }
        
        /* Capabilities */
        if (ports[5] != 0) {
            ports[0] = 1;
            switch(ports[5]) {
                case -1:  ports[5] = IMAGE_SIZE;
                    break;
                case -2:  ports[5] = 0;
                    break;
                case -3:  ports[5] = 0;
                    break;
                case -4:  ports[5] = 0;
                    break;
                case -5:  ports[5] = sp;
                    break;
                case -6:  ports[5] = rsp;
                    break;
                case -7:  ports[5] = 0;
                    break;
                case -8:  ports[5] = (int32_t)time(NULL);
                    break;
                case -9:  ports[5] = 0;
                    ip = IMAGE_SIZE;
                    break;
                case -10: ports[5] = 0;
                    [self queryEnvironment];
                    break;
                case -11: ioctl(0, TIOCGWINSZ, &w);
                    ports[5] = w.ws_col;
                    break;
                case -12: ioctl(0, TIOCGWINSZ, &w);
                    ports[5] = w.ws_row;
                    break;
                case -13: ports[5] = CELLSIZE;
                    break;
                case -14: ports[5] = 0; // VM_ENDIAN
                    break;
                case -15: ports[5] = -1;
                    break;
                case -16: ports[5] = STACK_DEPTH;
                    break;
                case -17: ports[5] = ADDRESSES;
                    break;
                default:  ports[5] = 0;
            }
        }
        
        if (ports[8] != 0) {
            switch (ports[8]) {
                case 1: ports[8] = 0;
                    printf("\e[%d;%dH", NOS, TOS);
                    DROP; DROP;
                    break;
                case 2: ports[8] = 0;
                    printf("\e[3%dm", TOS);
                    DROP;
                    break;
                case 3: ports[8] = 0;
                    printf("\e[4%dm", TOS);
                    DROP;
                    break;
                case 4: ports[8] = 0;
                    break;
                default: ports[8] = 0;
            }
        }
    }
}

/* The VM ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
- (void)processOpcode
{
    CELL a, b, opcode;
    opcode = image[ip];
    
    if (opcode > NUM_OPS)
        stats[NUM_OPS]++;
    else
        stats[opcode]++;
    
    switch(opcode) {
        case VM_NOP:
            break;
        case VM_LIT:
            sp++;
            ip++;
            TOS = image[ip];
            if (max_sp < sp)
                max_sp = sp;
            break;
        case VM_DUP:
            sp++;
            data[sp] = NOS;
            if (max_sp < sp)
                max_sp = sp;
            break;
        case VM_DROP:
            DROP
            break;
        case VM_SWAP:
            a = TOS;
            TOS = NOS;
            NOS = a;
            break;
        case VM_PUSH:
            rsp++;
            TORS = TOS;
            DROP
            if (max_rsp < rsp)
                max_rsp = rsp;
            break;
        case VM_POP:
            sp++;
            TOS = TORS;
            rsp--;
            break;
        case VM_LOOP:
            TOS--;
            ip++;
            if (TOS != 0 && TOS > -1)
                ip = image[ip] - 1;
            else
                DROP;
            break;
        case VM_JUMP:
            ip++;
            ip = image[ip] - 1;
            if (image[ip+1] == 0)
                ip++;
            if (image[ip+1] == 0)
                ip++;
            break;
        case VM_RETURN:
            ip = TORS;
            rsp--;
            if (image[ip+1] == 0)
                ip++;
            if (image[ip+1] == 0)
                ip++;
            break;
        case VM_GT_JUMP:
            ip++;
            if(NOS > TOS)
                ip = image[ip] - 1;
            DROP DROP
            break;
        case VM_LT_JUMP:
            ip++;
            if(NOS < TOS)
                ip = image[ip] - 1;
            DROP DROP
            break;
        case VM_NE_JUMP:
            ip++;
            if(TOS != NOS)
                ip = image[ip] - 1;
            DROP DROP
            break;
        case VM_EQ_JUMP:
            ip++;
            if(TOS == NOS)
                ip = image[ip] - 1;
            DROP DROP
            break;
        case VM_FETCH:
            TOS = image[TOS];
            break;
        case VM_STORE:
            image[TOS] = NOS;
            DROP DROP
            break;
        case VM_ADD:
            NOS += TOS;
            DROP
            break;
        case VM_SUB:
            NOS -= TOS;
            DROP
            break;
        case VM_MUL:
            NOS *= TOS;
            DROP
            break;
        case VM_DIVMOD:
            a = TOS;
            b = NOS;
            TOS = b / a;
            NOS = b % a;
            break;
        case VM_AND:
            a = TOS;
            b = NOS;
            DROP
            TOS = a & b;
            break;
        case VM_OR:
            a = TOS;
            b = NOS;
            DROP
            TOS = a | b;
            break;
        case VM_XOR:
            a = TOS;
            b = NOS;
            DROP
            TOS = a ^ b;
            break;
        case VM_SHL:
            a = TOS;
            b = NOS;
            DROP
            TOS = b << a;
            break;
        case VM_SHR:
            a = TOS;
            DROP
            TOS >>= a;
            break;
        case VM_ZERO_EXIT:
            if (TOS == 0) {
                DROP
                ip = TORS;
                rsp--;
            }
            break;
        case VM_INC:
            TOS += 1;
            break;
        case VM_DEC:
            TOS -= 1;
            break;
        case VM_IN:
            a = TOS;
            TOS = ports[a];
            ports[a] = 0;
            break;
        case VM_OUT:
            ports[TOS] = NOS;
            DROP DROP
            break;
        case VM_WAIT:
            [self deviceHandler];
            break;
        default:
            rsp++;
            TORS = ip;
            ip = image[ip] - 1;
            
            if (image[ip+1] == 0)
                ip++;
            if (image[ip+1] == 0)
                ip++;
            
            if (max_rsp < rsp)
                max_rsp = rsp;
            break;
    }
    ports[3] = 1;
}

/* Stats ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
- (void)displayStats
{
    int s, i;
    
    printf("Runtime Statistics\n");
    printf("NOP:     %d\n", stats[VM_NOP]);
    printf("LIT:     %d\n", stats[VM_LIT]);
    printf("DUP:     %d\n", stats[VM_DUP]);
    printf("DROP:    %d\n", stats[VM_DROP]);
    printf("SWAP:    %d\n", stats[VM_SWAP]);
    printf("PUSH:    %d\n", stats[VM_PUSH]);
    printf("POP:     %d\n", stats[VM_POP]);
    printf("LOOP:    %d\n", stats[VM_LOOP]);
    printf("JUMP:    %d\n", stats[VM_JUMP]);
    printf("RETURN:  %d\n", stats[VM_RETURN]);
    printf(">JUMP:   %d\n", stats[VM_GT_JUMP]);
    printf("<JUMP:   %d\n", stats[VM_LT_JUMP]);
    printf("!JUMP:   %d\n", stats[VM_NE_JUMP]);
    printf("=JUMP:   %d\n", stats[VM_EQ_JUMP]);
    printf("FETCH:   %d\n", stats[VM_FETCH]);
    printf("STORE:   %d\n", stats[VM_STORE]);
    printf("ADD:     %d\n", stats[VM_ADD]);
    printf("SUB:     %d\n", stats[VM_SUB]);
    printf("MUL:     %d\n", stats[VM_MUL]);
    printf("DIVMOD:  %d\n", stats[VM_DIVMOD]);
    printf("AND:     %d\n", stats[VM_AND]);
    printf("OR:      %d\n", stats[VM_OR]);
    printf("XOR:     %d\n", stats[VM_XOR]);
    printf("SHL:     %d\n", stats[VM_SHL]);
    printf("SHR:     %d\n", stats[VM_SHR]);
    printf("0;:      %d\n", stats[VM_ZERO_EXIT]);
    printf("INC:     %d\n", stats[VM_INC]);
    printf("DEC:     %d\n", stats[VM_DEC]);
    printf("IN:      %d\n", stats[VM_IN]);
    printf("OUT:     %d\n", stats[VM_OUT]);
    printf("WAIT:    %d\n", stats[VM_WAIT]);
    printf("CALL:    %d\n", stats[NUM_OPS]);
    printf("Max sp:  %d\n", max_sp);
    printf("Max rsp: %d\n", max_rsp);
    
    for (s = i = 0; s < NUM_OPS; s++)
        i += stats[s];
    printf("Total opcodes processed: %d\n", i);
}

- (void)run
{
    for (ip = 0; ip < IMAGE_SIZE; ip++)
        [self processOpcode];
}

- (void)runWithImage:(NSString *)imageName
{
    [self prepareInput];
    [self prepareOutput];
    [self loadImage: (char *)[imageName UTF8String]];
    [self run];
    [self restoreIO];
}

@end
