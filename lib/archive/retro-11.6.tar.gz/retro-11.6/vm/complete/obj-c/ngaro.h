//
//  Ngaro.h
//  ngaro
//
//  Created by Charles Childers on 3/9/14.
//  Copyright (c) 2014 Charles Childers. All rights reserved.
//
// Copyright (c) 2008 - 2013, Charles Childers
// Copyright (c) 2009 - 2010, Luke Parrish
// Copyright (c) 2010,        Marc Simpson
// Copyright (c) 2010,        Jay Skeer
// Copyright (c) 2011,        Kenneth Keating
//

#import <Foundation/Foundation.h>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <errno.h>

#define CELL            int32_t
#define IMAGE_SIZE      1000000
#define ADDRESSES          1024*1024
#define STACK_DEPTH         128
#define PORTS                12
#define MAX_FILE_NAME      1024
#define MAX_REQUEST_LENGTH 1024
#define MAX_OPEN_FILES        8
#define LOCAL                 "retroImage"
#define CELLSIZE             32


enum vm_opcode {VM_NOP, VM_LIT, VM_DUP, VM_DROP, VM_SWAP, VM_PUSH, VM_POP,
    VM_LOOP, VM_JUMP, VM_RETURN, VM_GT_JUMP, VM_LT_JUMP,
    VM_NE_JUMP,VM_EQ_JUMP, VM_FETCH, VM_STORE, VM_ADD,
    VM_SUB, VM_MUL, VM_DIVMOD, VM_AND, VM_OR, VM_XOR, VM_SHL,
    VM_SHR, VM_ZERO_EXIT, VM_INC, VM_DEC, VM_IN, VM_OUT,
    VM_WAIT };
#define NUM_OPS VM_WAIT + 1

/* Macros ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
#define DROP { data[sp] = 0; if (--sp < 0) ip = IMAGE_SIZE; }
#define TOS  data[sp]
#define NOS  data[sp-1]
#define TORS address[rsp]

@interface Ngaro : NSObject {
    CELL sp, rsp, ip;
    CELL data[STACK_DEPTH];
    CELL address[ADDRESSES];
    CELL ports[PORTS];
    FILE *files[MAX_OPEN_FILES];
    FILE *input[MAX_OPEN_FILES];
    CELL isp;
    CELL image[IMAGE_SIZE];
    CELL shrink;
    CELL filecells; // in image on disk
    int stats[NUM_OPS + 1];
    int max_sp, max_rsp;
    char filename[MAX_FILE_NAME];
    char request[MAX_REQUEST_LENGTH];
    struct termios new_termios, old_termios;
}

- (void)getString:(int) starting;
- (void)writeConsole:(CELL) c;
- (CELL)readConsole;
- (void)includeFile:(char *) s;
- (void)prepareInput;
- (void)prepareOutput;
- (void)restoreIO;
- (CELL)getFileHandle;
- (void)addInputSource;
- (CELL)openFile;
- (CELL)readFile;
- (CELL)writeFile;
- (CELL)getFilePosition;
- (CELL)setFilePosition;
- (CELL)getFileSize;
- (CELL)deleteFile;
- (CELL)loadImage:(char *)imageName;
- (CELL)saveImage:(char *)image;
- (void)queryEnvironment;
- (void)deviceHandler;
- (void)processOpcode;
- (void)displayStats;
- (void)run;
- (void)runWithImage:(NSString *)imageName;

@end
