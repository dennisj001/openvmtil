=======================
Ngaro VM in Common Lisp
=======================

-----
CLISP
-----

::

  ln -s ../../../retroImage .
  clisp retro.lisp


----
SBCL
----

::

  ln -s ../../../retroImage .
  sbcl --no-sysinit --no-userinit --noprint --load sbcl.lisp

